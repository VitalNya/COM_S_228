package edu.iastate.cs228.hw2;



/**
 *  
 * @author Vital Nyabashi
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.
 *
 */

public class MergeSorter extends AbstractSorter {
	// Other private instance variables if needed

	/**
	 * Constructor takes an array of points. It invokes the superclass constructor,
	 * and also set the instance variables algorithm in the superclass.
	 * 
	 * @param pts input array of integers
	 */
	public MergeSorter(Point[] pts) {
		super(pts);
		algorithm = "merge sort";
		// TODO
	}

	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter.
	 * 
	 */
	@Override
	public void sort() {
		mergeSortRec(points); // Call mergeSortRec() with the array points[]
		// TODO
	}

	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of
	 * points. One way is to make copies of the two halves of pts[], recursively
	 * call mergeSort on them, and merge the two sorted subarrays into pts[].
	 * 
	 * @param pts point array
	 */
	private void mergeSortRec(Point[] pts) {
		if (pts.length < 2) {
			return; // Base case: if the array has 0 or 1 elements, it is already sorted
		}
		// Split the array into two halves
		int mid = pts.length / 2;
		Point[] leftArray = new Point[mid];
		Point[] rightArray = new Point[pts.length - mid];
		System.arraycopy(pts, 0, leftArray, 0, mid);
		System.arraycopy(pts, mid, rightArray, 0, pts.length - mid);

		// Recursively sort the two halves
		mergeSortRec(leftArray);
		mergeSortRec(rightArray);

		// Merge the sorted halves
		merge(pts, leftArray, rightArray);
	}

	/**
	 * Merge two sorted arrays left[] and right[] into pts[].
	 * 
	 * @param pts   The array to merge into
	 * @param left  The left half of the array
	 * @param right The right half of the array
	 */
	private void merge(Point[] pts, Point[] left, Point[] right) {
		int i = 0, j = 0, k = 0;
		while (i < left.length && j < right.length) {
			if (left[i].compareTo(right[j]) <= 0) {
				pts[k++] = left[i++];
			} else {
				pts[k++] = right[j++];
			}
		}

		// Copy remaining elements of left[] if any
		while (i < left.length) {
			pts[k++] = left[i++];
		}

		// Copy remaining elements of right[] if any
		while (j < right.length) {
			pts[k++] = right[j++];
		}
	}
}
