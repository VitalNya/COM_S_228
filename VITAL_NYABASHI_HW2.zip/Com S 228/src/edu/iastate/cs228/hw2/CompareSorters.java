package edu.iastate.cs228.hw2;

/**
 *  
 * @author Vital Nyabashi
 *
 */

/**
 * 
 * This class executes four sorting algorithms: selection sort, insertion sort, mergesort, and
 * quicksort, over randomly generated integers as well integers from a file input. It compares the 
 * execution times of these algorithms on the same input. 
 *
 */

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Random;

public class CompareSorters {
	/**
	 * Repeatedly take integer sequences either randomly generated or read from
	 * files. Use them as coordinates to construct points. Scan these points with
	 * respect to their median coordinate point four times, each time using a
	 * different sorting algorithm.
	 * 
	 * @param args
	 * @throws FileNotFoundException if the input file is not found
	 **/
	public static void main(String[] args) throws FileNotFoundException {
		Scanner scanner = new Scanner(System.in);
		Random rand = new Random();
		int trialNum = 1;

		while (true) {
	        System.out.println("Trial " + trialNum++ + ":");
	        System.out.println("keys: 1 (random integers) 2 (file input) 3 (exit)");
	        int key = scanner.nextInt();
	        if (key == 3) {
	            break;
	        } else if (key == 1 || key == 2) {
	            Point[] points;
	            if (key == 1) {
	                System.out.println("Enter number of random points:");
	                int numPts = scanner.nextInt();
	                points = generateRandomPoints(numPts, rand);
	            } else {
	                System.out.println("Points from a file\nFile name:");
	                String fileName = scanner.next();
	                PointScanner fileScanner = new PointScanner(fileName, null);
	                points = new Point[fileScanner.points.length];
	                fileScanner.getPoints(points);
	            }

	            System.out.printf("%-15s%-7s%-7s%n", "algorithm", "size", "time (ns)");
	            System.out.println("----------------------------------");

	            for (Algorithm algo : Algorithm.values()) {
	                PointScanner pointScanner = new PointScanner(points, algo);
	                pointScanner.scan();
	                System.out.printf("%-15s%-7d%-7d%n", algo, points.length, pointScanner.scanTime);
	            }

	            System.out.println("----------------------------------");
	        } else {
	            System.out.println("KEY VALUE IS NOT ONE OF THE OPTIONS");
	        }
	    }
	    scanner.close();
	}

	/**
	 * This method generates a given number of random points. The coordinates of
	 * these points are pseudo-random numbers within the range [-50,50] � [-50,50].
	 * Please refer to Section 3 on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing.
	 * 
	 * @param numPts number of points to generate
	 * @param rand   Random object to allow seeding of the random number generator
	 * @return an array of random points
	 * @throws IllegalArgumentException if numPts < 1
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException {
		if (numPts < 1) {
			throw new IllegalArgumentException("Number of points must be at least 1");
		}

		Point[] randomPoints = new Point[numPts];
		for (int i = 0; i < numPts; i++) {
			int x = rand.nextInt(101) - 50; // Generates random x-coordinate in [-50, 50]
			int y = rand.nextInt(101) - 50; // Generates random y-coordinate in [-50, 50]
			randomPoints[i] = new Point(x, y);
		}
		return randomPoints;
	}
}