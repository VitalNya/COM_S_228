package edu.iastate.cs228.hw2;

/**
 *  
 * @author Vital Nyabashi
 *
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * 
 * This class sorts all the points in an array of 2D points to determine a
 * reference point whose x and y coordinates are respectively the medians of the
 * x and y coordinates of the original points.
 * 
 * It records the employed sorting algorithm as well as the sorting time for
 * comparison.
 *
 */
public class PointScanner {
	protected Point[] points;

	private Point medianCoordinatePoint; // point whose x and y coordinates are respectively the medians of
											// the x coordinates and y coordinates of those points in the array
											// points[].
	private Algorithm sortingAlgorithm;

	protected long scanTime; // execution time in nanoseconds.

	/**
	 * This constructor accepts an array of points and one of the four sorting
	 * algorithms as input. Copy the points into the array points[].
	 * 
	 * @param pts input array of points
	 * @throws IllegalArgumentException if pts == null or pts.length == 0.
	 */
	public PointScanner(Point[] pts, Algorithm algo) throws IllegalArgumentException {
		if (pts == null || pts.length == 0) {
			throw new IllegalArgumentException("Input array of points cannot be null or empty");
		}
		this.points = pts.clone();
		this.sortingAlgorithm = algo;

	}

	/**
	 * Retrieves the array of points stored in the PointScanner.
	 * 
	 * @param dest destination array to store the points
	 * @throws IllegalArgumentException if dest is null or its length is not equal
	 *                                  to the number of points
	 */
	public void getPoints(Point[] dest) {
		if (dest == null || dest.length != points.length) {
			throw new IllegalArgumentException("Destination array is null or has incorrect length");
		}
		System.arraycopy(points, 0, dest, 0, points.length);
	}

	/**
	 * This constructor reads points from a file.
	 * 
	 * @param inputFileName
	 * @throws FileNotFoundException
	 * @throws InputMismatchException if the input file contains an odd number of
	 *                                integers
	 */
	protected PointScanner(String inputFileName, Algorithm algo) throws FileNotFoundException, InputMismatchException {
		this.sortingAlgorithm = algo;
		File file = new File(inputFileName);
		Scanner scanner = new Scanner(file);
		int count = 0;
		while (scanner.hasNextInt()) {
			scanner.nextInt();
			count++;
		}
		if (count % 2 != 0) {
			scanner.close(); // Close the scanner before throwing the exception
			throw new InputMismatchException("The input file must contain an even number of integers.");
		}
		this.points = new Point[count / 2];
		scanner.close(); // Close the scanner before reopening it
		scanner = new Scanner(file);
		for (int i = 0; i < points.length; i++) {
			int x = scanner.nextInt();
			int y = scanner.nextInt();
			points[i] = new Point(x, y);
		}
		scanner.close(); // Close the scanner after reading points
	}

	/**
	 * Carry out two rounds of sorting using the algorithm designated by
	 * sortingAlgorithm as follows:
	 * 
	 * a) Sort points[] by the x-coordinate to get the median x-coordinate. b) Sort
	 * points[] again by the y-coordinate to get the median y-coordinate. c)
	 * Construct medianCoordinatePoint using the obtained median x- and
	 * y-coordinates.
	 * 
	 * Based on the value of sortingAlgorithm, create an object of SelectionSorter,
	 * InsertionSorter, MergeSorter, or QuickSorter to carry out sorting.
	 * 
	 * @param algo
	 * @return
	 */
	public void scan() {
	    long startTime = System.nanoTime(); // Record start time
	    AbstractSorter sorter;
	    switch (sortingAlgorithm) {
	        case SelectionSort:
	            sorter = new SelectionSorter(points);
	            break;
	        case InsertionSort:
	            sorter = new InsertionSorter(points);
	            break;
	        case MergeSort:
	            sorter = new MergeSorter(points);
	            break;
	        case QuickSort:
	            sorter = new QuickSorter(points);
	            break;
	        default:
	            throw new IllegalArgumentException("Invalid sorting algorithm.");
	    }

	    sorter.setComparator(0);
	    sorter.sort();
	    int medianX = sorter.getMedian().getX();
	    sorter.setComparator(1);
	    sorter.sort();
	    int medianY = sorter.getMedian().getY();
	    medianCoordinatePoint = new Point(medianX, medianY);

	    long endTime = System.nanoTime(); // Record end time
	    scanTime = endTime - startTime; // Calculate elapsed time

		// create an object to be referenced by aSorter according to sortingAlgorithm.
		// for each of the two
		// rounds of sorting, have aSorter do the following:
		//
		// a) call setComparator() with an argument 0 or 1.
		//
		// b) call sort().
		//
		// c) use a new Point object to store the coordinates of the
		// medianCoordinatePoint
		//
		// d) set the medianCoordinatePoint reference to the object with the correct
		// coordinates.
		//
		// e) sum up the times spent on the two sorting rounds and set the instance
		// variable scanTime.

	}

	/**
	 * Outputs performance statistics in the format:
	 * 
	 * <sorting algorithm> <size> <time>
	 * 
	 * For instance,
	 * 
	 * selection sort 1000 9200867
	 * 
	 * Use the spacing in the sample run in Section 2 of the project description.
	 */
	public String stats() {
	    return sortingAlgorithm + " " + points.length + " " + scanTime;
		// TODO
	}

	/**
	 * Write MCP after a call to scan(), in the format "MCP: (x, y)" The x and y
	 * coordinates of the point are displayed on the same line with exactly one
	 * blank space in between.
	 */
	@Override
	public String toString() {
		return "MCP: (" + medianCoordinatePoint.getX() + ", " + medianCoordinatePoint.getY() + ")";
		// TODO
	}

	/**
	 * 
	 * This method, called after scanning, writes point data into a file by
	 * outputFileName. The format of data in the file is the same as printed out
	 * from toString(). The file can help you verify the full correctness of a
	 * sorting result and debug the underlying algorithm.
	 * @throws IOException 
	 */
	public void writeMCPToFile() throws IOException {
		    FileWriter writer = new FileWriter("output.txt");
		    try {
				writer.write(toString() + "\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    try {
				writer.write("Sorted Points:\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    for (Point point : points) {
		        try {
					writer.write(point.toString() + "\n");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    }
		    writer.close();
		}
	}