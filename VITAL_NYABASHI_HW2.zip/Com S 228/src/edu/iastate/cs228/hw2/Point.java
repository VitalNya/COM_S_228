 package edu.iastate.cs228.hw2;

/**
 *  
 * @author Vital Nyabashi
 *
 */
 
 /**
  * Represents a point in 2D space with integer coordinates.
  * Supports comparison based on either x or y coordinates.
  * Provides methods to set and retrieve coordinates, compare points, and format output.
  */
public class Point implements Comparable<Point>
{
	private int x; 
	private int y;
	
	
	  /**
     * Indicates whether comparison is based on x or y coordinates.
     */
	
	public static boolean xORy;  // compare x coordinates if xORy == true and y coordinates otherwise 
	                             // To set its value, use Point.xORy = true or false. 
	
	
	/**
     * Constructs a point with default coordinates (0, 0).
     */
	public Point()  // default constructor
	{
		// x and y get default value 0
	}
	
	

    /**
     * Constructs a point with given coordinates.
     *
     * @param x the x-coordinate
     * @param y the y-coordinate
     */
	public Point(int x, int y)
	{
		this.x = x;  
		this.y = y;   
	}
	
	
	/**
     * Constructs a point by copying another point.
     *
     * @param p the point to copy
     */
	public Point(Point p) { // copy constructor
		x = p.getX();
		y = p.getY();
	}


	/**
     * Gets the x-coordinate of the point.
     *
     * @return the x-coordinate
     */
	public int getX()   
	{
		return x;
	}
	
	/**
     * Gets the y-coordinate of the point.
     *
     * @return the y-coordinate
     */
	public int getY()
	{
		return y;
	}
	
	/** 
	 * Set the value of the static instance variable xORy. 
	 * @param xORy
	 */
	public static void setXorY(boolean xORy)
	{
        Point.xORy = xORy;
		 
	}
	
	
	/**
	 * Overrides the equals method to compare this Point with another object for equality.
	 * 
	 * @param obj The object to compare with.
	 * @return True if the object is a Point and has the same x and y coordinates as this Point, false otherwise.
	 */
	@Override
	public boolean equals(Object obj)
	{
		// Check if the object is null or of a different class
		if (obj == null || obj.getClass() != this.getClass())
		{
			return false;
		}
    
		// Cast the object to a Point
		Point other = (Point) obj;
		
		// Check if the x and y coordinates of the two points are equal
		return x == other.x && y == other.y;   
	}

	/**
	 * Compare this point with a second point q depending on the value of the static variable xORy 
	 * @param 	q 
	 * @return  -1  if (xORy == true && (this.x < q.x || (this.x == q.x && this.y < q.y))) 
	 *                || (xORy == false && (this.y < q.y || (this.y == q.y && this.x < q.x)))
	 * 		    0   if this.x == q.x && this.y == q.y)  
	 * 			1	otherwise 
	 */
	@Override
	public int compareTo(Point q) {
	    if (xORy) { // If comparison is based on x coordinates
	        if (x != q.x) { // Compare x coordinates first
	            return Integer.compare(x, q.x);
	        } else { // If x coordinates are equal, compare y coordinates
	            return Integer.compare(y, q.y);
	        }
	    } else { // If comparison is based on y coordinates
	        if (y != q.y) { // Compare y coordinates first
	            return Integer.compare(y, q.y);
	        } else { // If y coordinates are equal, compare x coordinates
	            return Integer.compare(x, q.x);
	        }
	    }
	}
	
	
	/**
	 * Output a point in the standard form (x, y). 
	 */
	@Override
    public String toString() 
	{
		 
		return "(" + x + ", " + y + ")"; 
	}
}
