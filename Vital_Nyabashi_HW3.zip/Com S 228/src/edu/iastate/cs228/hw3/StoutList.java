package edu.iastate.cs228.hw3;

/**
 *  
 * @author Vital Nyabashi
 * ISU Com S 228 Spring 2024
 */

import java.util.AbstractSequentialList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * Implementation of the list interface based on linked nodes that store
 * multiple items per node. Rules for adding and removing elements ensure that
 * each node (except possibly the last one) is at least half full.
 */
public class StoutList<E extends Comparable<? super E>> extends AbstractSequentialList<E> {
	/**
	 * Default number of elements that may be stored in each node.
	 */
	private static final int DEFAULT_NODESIZE = 4;

	/**
	 * Number of elements that can be stored in each node.
	 */
	private final int nodeSize;

	/**
	 * Dummy node for head. It should be private but set to public here only for
	 * grading purpose. In practice, you should always make the head of a linked
	 * list a private instance variable.
	 */
	public Node head;

	/**
	 * Dummy node for tail.
	 */
	private Node tail;

	/**
	 * Number of elements in the list.
	 */
	private int size;

	/**
	 * Constructs an empty list with the default node size.
	 */

	public Node node;

	public StoutList() {
		this(DEFAULT_NODESIZE);
	}

	/**
	 * Constructs an empty list with the given node size.
	 * 
	 * @param nodeSize number of elements that may be stored in each node, must be
	 *                 an even number
	 */
	public StoutList(int nodeSize) {
		if (nodeSize <= 0 || nodeSize % 2 != 0)
			throw new IllegalArgumentException();

		// dummy nodes
		head = new Node();
		tail = new Node();
		head.next = tail;
		tail.previous = head;
		this.nodeSize = nodeSize;
	}

	/**
	 * Constructor for grading only. Fully implemented.
	 * 
	 * @param head
	 * @param tail
	 * @param nodeSize
	 * @param size
	 */
	public StoutList(Node head, Node tail, int nodeSize, int size) {
		this.head = head;
		this.tail = tail;
		this.nodeSize = nodeSize;
		this.size = size;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean add(E item) {
		// Check if the item is null and throw NullPointerException if so
		if (item == null) {
			throw new NullPointerException();
		}

		// Create a new node and add the item to it
		Node newNode = new Node();
		newNode.addItem(item);

		// If the list is empty, add the node between head and tail
		if (size == 0) {
			head.next = newNode;
			newNode.previous = head;
			newNode.next = tail;
			tail.previous = newNode;
		} else {
			Node lastNode = tail.previous;
			// If the last node has space, add the item to it
			if (lastNode.count < nodeSize) {
				lastNode.addItem(item);
			} else {
				// Otherwise, add a new node after the last node
				lastNode.next = newNode;
				newNode.previous = lastNode;
				newNode.next = tail;
				tail.previous = newNode;
			}
		}
		// Increase the size of the list
		size++;
		return true; // Indicate that the item has been added
	}

	/**
	 * Adds item to a specific index
	 *
	 * @param pos  the position where the item should go to
	 * @param item the item to add to the list
	 */
	@Override
	public void add(int pos, E item) {
		if (pos < 0 || pos > size)
			throw new IndexOutOfBoundsException();

		// If the list is empty or adding at the end, simply call the add method
		if (isEmpty() || pos == size) {
			add(item);
			return;
		}

		NodeInfo nodeInfo = find(pos);
		Node node = nodeInfo.node;
		int offset = nodeInfo.offset;

		if (node.count < nodeSize) {
			// If there's space in the node, simply add the item
			node.addItem(offset, item);
		} else {
			// Perform a split operation
			Node replacment = new Node();
			int middle = nodeSize / 2;

			// Move the elements after the split point to the new successor node
			for (int i = middle; i < nodeSize; i++) {
				replacment.addItem(node.data[i]);
				node.removeItem(middle);
			}

			// Adjust the pointers
			Node prev = node.next;
			node.next = replacment;
			replacment.previous = node;
			replacment.next = prev;
			prev.previous = replacment;

			// Decide where to add the item
			if (offset <= middle) {
				// Add to the current node
				node.addItem(offset, item);
			} else {
				// Add to the new successor node
				replacment.addItem(offset - middle, item);
			}
		}
		// Increase the size of the list
		size++;
	}

	/**
	 * Removes an element from the list at the specified position.
	 * 
	 * @param pos the position of the element to be removed
	 * @return the removed element
	 * @throws IndexOutOfBoundsException if the position is out of bounds
	 */
	@Override
	public E remove(int pos) {
		if (pos < 0 || pos >= size)
			throw new IndexOutOfBoundsException("INVALID VALUE. THIS VALUE IS OUT OF BOUNDS");
		NodeInfo nodeInfo = find(pos);
		Node hold = nodeInfo.node;
		int offset = nodeInfo.offset;
		E node = hold.data[offset];

		// Remove the item from the current node
		hold.removeItem(offset);

		// If the node is empty after removal, delete it
		if (hold.count == 0) {
			hold.previous.next = hold.next;
			hold.next.previous = hold.previous;
			hold = null;
		} else if (hold.next != tail && hold.count < nodeSize / 2) {
			// If the node has fewer than M/2 elements, merge with successor
			Node replacement = hold.next;

			if (replacement.count <= nodeSize / 2) {
				// Full merge
				System.arraycopy(replacement.data, 0, hold.data, hold.count, replacement.count);
				hold.count += replacement.count;
				hold.next = replacement.next;
				replacement.next.previous = hold;
				replacement = null;
			} else {
				// Mini merge
				hold.addItem(replacement.data[0]);
				replacement.removeItem(0);
			}
		}

		size--;
		return node;
	}

	/**
	 * Finds the node and offset corresponding to the given position in the list.
	 * 
	 * @param pos the position in the list
	 * @return a NodeInfo object containing the node and offset
	 * @throws IndexOutOfBoundsException if the position is out of bounds
	 * @throws IllegalStateException     if the node corresponding to the position
	 *                                   is not found (should not happen if the
	 *                                   input is valid)
	 */
	private NodeInfo find(int pos) {
		if (pos < 0 || pos >= size)
			throw new IndexOutOfBoundsException();

		Node hold = head.next;
		int postion = 0;

		while (hold != null) {
			if (postion + hold.count <= pos) {
				postion += hold.count;
				hold = hold.next;
			} else {
				return new NodeInfo(hold, pos - postion);
			}
		}
		// This should not be reached if the input is valid, but added for completeness
		throw new IllegalStateException("Node not found for position: " + pos);
	}

	/**
	 * A helper class to store infomation \bout a node and its offset within the node.
     * Constructs a NodeInfo object with the given node and offset.
     * 
     * @param node   the node containing the element
     * @param offset the offset of the element within the node
     */
	private class NodeInfo {
		private final Node node;
		private final int offset;

		public NodeInfo(Node node, int offset) {
			this.node = node;
			this.offset = offset;
		}
	}

	/**
	 * Sort all elements in the stout list in the NON-DECREASING order. You may do
	 * the following. Traverse the list and copy its elements into an array,
	 * deleting every visited node along the way. Then, sort the array by calling
	 * the insertionSort() method. (Note that sorting efficiency is not a concern
	 * for this project.) Finally, copy all elements from the array back to the
	 * stout list, creating new nodes for storage. After sorting, all nodes but
	 * (possibly) the last one must be full of elements.
	 * 
	 * Comparator<E> must have been implemented for calling insertionSort().
	 */

	@SuppressWarnings({ "unchecked" })
	public void sort() {
		E[] sortDataList = (E[]) new Comparable[size];

		int index = 0;
		Node hold = head.next;
		while (hold != tail) {
			for (int i = 0; i < hold.count; i++) {
				sortDataList[index] = hold.data[i];
				index++;
			}
			hold = hold.next;
		}

		head.next = tail;
		tail.previous = head;

		insertionSort(sortDataList, new comparator());
		size = 0;
		for (int i = 0; i < sortDataList.length; i++) {
			add(sortDataList[i]);
		}
	}

	private class comparator implements Comparator<E> {
		@Override
		public int compare(E arg0, E arg1) {
			if (arg0 == null && arg1 == null) {
				return 0;
			}
			if (arg0 == null) {
				return -1;
			}
			if (arg1 == null) {
				return 1;
			}
			return arg0.compareTo(arg1);
		}
	}

	/**
	 * Sort all elements in the stout list in the NON-INCREASING order. Call the
	 * bubbleSort() method. After sorting, all but (possibly) the last nodes must be
	 * filled with elements.
	 * 
	 * Comparable<? super E> must be implemented for calling bubbleSort().
	 */
	public void sortReverse() {
		@SuppressWarnings("unchecked")
		E[] sortReverse = (E[]) new Comparable[size];

		int index = 0;
		Node hold = head.next;
		while (hold != tail) {
			for (int i = 0; i < hold.count; i++) {
				sortReverse[index++] = hold.data[i];

			}
			hold = hold.next;
		}
		head.next = tail;
		tail.previous = head;
		bubbleSort(sortReverse);

		size = 0;
		Node currentNode = head;
		for (E element : sortReverse) {
			addAfter(currentNode, element);
			currentNode = currentNode.next;
		}
	}

	/**
	 * Adds a new node containing the specified element after the given node.
	 * 
	 * @param prevNode the node after which to add the new node
	 * @param element  the element to add to the list
	 */
	private void addAfter(Node prevNode, E element) {
		Node newNode = new Node();
		newNode.data[0] = element; // Assuming the first element of the data array is used
		newNode.count = 1; // Assuming we always add a single element
		newNode.next = prevNode.next;
		prevNode.next = newNode;
		newNode.previous = prevNode;
		if (newNode.next != null) {
			newNode.next.previous = newNode;
		} else {
			tail = newNode; // Update the tail if newNode is the new last node
		}
		size++;
	}

	@Override
	public Iterator<E> iterator() {
		return new StoutListIterator();
	}

	@Override
	public ListIterator<E> listIterator() {
		return new StoutListIterator();
	}

	@Override
	public ListIterator<E> listIterator(int index) {
		return new StoutListIterator(index);
	}

	/**
	 * Returns a string representation of this list showing the internal structure
	 * of the nodes.
	 */
	public String toStringInternal() {
		return toStringInternal(null);
	}

	/**
	 * Returns a string representation of this list showing the internal structure
	 * of the nodes and the position of the iterator.
	 *
	 * @param iter an iterator for this list
	 */
	public String toStringInternal(ListIterator<E> iter) {
		int count = 0;
		int position = -1;
		if (iter != null) {
			position = iter.nextIndex();
		}

		StringBuilder sb = new StringBuilder();
		sb.append('[');
		Node current = head.next;
		while (current != tail) {
			sb.append('(');
			boolean isFirstElement = true; // Flag to track if it's the first element in the node
			for (int i = 0; i < nodeSize; ++i) {
				E data = current.data[i];
				if (data != null) {
					if (isFirstElement) {
						isFirstElement = false;
					} else {
						sb.append(", ");
					}
					if (position == count) {
						sb.append("| ");
						position = -1;
					}
					sb.append(data.toString());
					++count;
				}
			}
			sb.append(')');
			current = current.next;
			if (current != tail)
				sb.append(", ");
		}
		sb.append("]");
		return sb.toString();
	}

	/**
	 * Node type for this list. Each node holds a maximum of nodeSize elements in an
	 * array. Empty slots are null.
	 */
	private class Node {
		/**
		 * Array of actual data elements.
		 */
		// Unchecked warning unavoidable.
		@SuppressWarnings("unchecked")
		public E[] data = (E[]) new Comparable[nodeSize];

		/**
		 * Link to next node.
		 */
		public Node next;

		/**
		 * Link to previous node;
		 */
		public Node previous;

		/**
		 * Index of the next available offset in this node, also equal to the number of
		 * elements in this node.
		 */
		public int count;

		/**
		 * Adds an item to this node at the first available offset. Precondition: count
		 * < nodeSize
		 * 
		 * @param item element to be added
		 */
		void addItem(E item) {
			if (count >= nodeSize) {
				return;
			}
			data[count++] = item;
			// useful for debugging
//			 System.out.println("Added " + item.toString() + " at index " + count + " to node " + Arrays.toString(data));
		}

		/**
		 * Adds an item to this node at the indicated offset, shifting elements to the
		 * right as necessary.
		 * 
		 * Precondition: count < nodeSize
		 * 
		 * @param offset array index at which to put the new element
		 * @param item   element to be added
		 */
		void addItem(int offset, E item) {
			if (count >= nodeSize) {
				return;
			}
			for (int i = count - 1; i >= offset; --i) {
				data[i + 1] = data[i];
			}
			++count;
			data[offset] = item;
			// useful for debugging
//      System.out.println("Added " + item.toString() + " at index " + offset + " to node: "  + Arrays.toString(data));
		}

		/**
		 * Deletes an element from this node at the indicated offset, shifting elements
		 * left as necessary. Precondition: 0 <= offset < count
		 * 
		 * @param offset
		 */
		void removeItem(int offset) {
			@SuppressWarnings("unused")
			E item = data[offset];
			for (int i = offset + 1; i < nodeSize; ++i) {
				data[i - 1] = data[i];
			}
			data[count - 1] = null;
			--count;
		}
	}

	private class StoutListIterator implements ListIterator<E> {
		// constants you possibly use ...
		private int prevMove;
		private E[] dataList;
		private int lastPrev = 0;
		private int lastNext = 1;
		private int current;
		// instance variables ...

		/**
		 * Default constructor
		 */
		public StoutListIterator() {
			current = 0;
			prevMove--;
			initializeDataList();
		}

		/**
		 * Constructor finds node at a given position.
		 * 
		 * @param pos
		 */
		public StoutListIterator(int pos) {
			current = pos;
			prevMove--;
			initializeDataList();
		}

		@Override
		public boolean hasNext() {
			return current < size;
		}

		@Override
		public E next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			prevMove = lastNext;
			return dataList[current];
		}

		@Override
		public void remove() {
			if (prevMove == lastNext || prevMove == lastPrev) {
				// Calculate the postion t remove based on the last action
				int removeablePostion = (prevMove == lastNext) ? current - 1 : current;
				// Remove the element at the calculated postion
				StoutList.this.remove(removeablePostion);
				// Re-setip the list after removal
				initializeDataList();
				// Reset the last action
				prevMove--;
			}
		}

		@SuppressWarnings("unchecked")
		private void initializeDataList() {
			dataList = (E[]) new Comparable[size];
			int index = 0;
			Node hold = head.next;
			while (hold != null) {
				System.arraycopy(hold.data, 0, dataList, index, hold.count);
				index += hold.count;
				hold = hold.next;
			}
		}

		@Override
		public boolean hasPrevious() {
			return current > 0;
		}

		@Override
		public E previous() {
			if (hasPrevious() == false) {
				throw new NoSuchElementException();
			} else {
				prevMove = lastPrev;
				current--;
				return dataList[current];
			}
		}

		@Override
		public int nextIndex() {
			return current;
		}

		@Override
		public int previousIndex() {
			return current - 1;
		}

		@Override
		public void set(E e) {
			if (!(prevMove == lastNext || prevMove == lastPrev)) {
				throw new IllegalStateException();
			}
			NodeInfo info = find(prevMove == lastNext ? current - 1 : current);
			info.node.data[info.offset] = e;
			dataList[current] = e;
		}

		@Override
		public void add(E e) {
			if (e == null) {
				throw new NullPointerException();
			}

			StoutList.this.add(current, e);
			current++;
			initializeDataList();
			prevMove = -1;

		}

		// Other methods you may want to add or override that could possibly facilitate
		// other operations, for instance, addition, access to the previous element,
		// etc.
		//
		// ...
		//
	}

	/**
	 * Sort an array arr[] using the insertion sort algorithm in the NON-DECREASING
	 * order.
	 * 
	 * @param arr  array storing elements from the list
	 * @param comp comparator used in sorting
	 */
	private void insertionSort(E[] arr, Comparator<? super E> comp) {
		int n = arr.length;
		for (int i = 1; i < n; ++i) {
			E key = arr[i];
			int j = i - 1;
			while (j >= 0 && comp.compare(arr[j], key) > 0) {
				arr[j + 1] = arr[j];
				j = j - 1;
			}
			arr[j + 1] = key;
		}
	}

	/**
	 * Sort arr[] using the bubble sort algorithm in the NON-INCREASING order. For a
	 * description of bubble sort please refer to Section 6.1 in the project
	 * description. You must use the compareTo() method from an implementation of
	 * the Comparable interface by the class E or ? super E.
	 * 
	 * @param arr array holding elements from the list
	 */
	private void bubbleSort(E[] arr) {
		int n = arr.length;
		for (int i = 0; i < n - 1; i++) {
			for (int j = 0; j < n - i - 1; j++) {
				E hold = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = hold;
			}
		}
	}

}