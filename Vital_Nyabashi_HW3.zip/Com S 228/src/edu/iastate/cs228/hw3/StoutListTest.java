package edu.iastate.cs228.hw3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StoutListTest {
	private StoutList<String> list;

	@BeforeEach
	public void setup() {
		list = new StoutList<>();
	}

	@Test
	public void testAdd() {
		list.add("a");
		assertEquals(1, list.size());
		assertEquals("a", list.get(0));
	}

	@Test
	public void testAddAtIndex() {
		list.add(0, "a");
		assertEquals(1, list.size());
		assertEquals("a", list.get(0));
	}

	@Test
	public void testRemove() {
		list.add("a");
		list.remove(0);
		assertEquals(0, list.size());
	}

	@Test
	public void testSort() {
		list.add("c");
		list.add("a");
		list.add("b");
		list.sort();
		assertEquals("a", list.get(0));
		assertEquals("b", list.get(1));
		assertEquals("c", list.get(2));
	}

	@Test
	public void testSortReverse() {
		list.add("a");
		list.add("b");
		list.add("c");
		list.sortReverse();
		assertEquals("c", list.get(0));
		assertEquals("b", list.get(1));
		assertEquals("a", list.get(2));
	}

	@Test
	public void testGet() {
		list.add("a");
		list.add("b");
		list.add("c");
		assertEquals("a", list.get(0));
		assertEquals("b", list.get(1));
		assertEquals("c", list.get(2));
	}

	@Test
	public void testIsEmpty() {
		assertTrue(list.isEmpty());
		list.add("a");
		assertFalse(list.isEmpty());
	}

	@Test
	public void testSize() {
		assertEquals(0, list.size());
		list.add("a");
		assertEquals(1, list.size());
		list.add("b");
		assertEquals(2, list.size());
	}

	 @Test
	    public void testToStringInternal() {
	        // Create a new StoutList instance
	        StoutList<Integer> list = new StoutList<>();
	        
	        // Add some elements to the list
	        list.add(10);
	        list.add(20);
	        list.add(30);
	        list.add(30);
	        
	        // Call the toStringInternal() method
	        String actual = list.toStringInternal();
	        
	        // Define the expected output based on the internal structure of the list
	        String expected = "[(10, 20, 30, 30)]";
	        
	        // Compare the expected output with the actual output
	        assertEquals(expected, actual);
	 }

	@Test
	public void testAddNullElement() {
		assertThrows(NullPointerException.class, () -> list.add(null));
	}

	@Test
	public void testAddAtIndexOutOfBounds() {
		assertThrows(IndexOutOfBoundsException.class, () -> list.add(1, "a"));
	}

	@Test
	public void testRemoveOutOfBounds() {
		assertThrows(IndexOutOfBoundsException.class, () -> list.remove(0));
	}
}
