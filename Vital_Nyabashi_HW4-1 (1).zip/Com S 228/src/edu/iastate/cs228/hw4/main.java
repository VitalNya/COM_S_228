package edu.iastate.cs228.hw4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        main main = new main();
        main.processInput();
    }

    public void processInput() {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the filename
        System.out.print("Please enter filename to decode: ");
        String filename = scanner.nextLine();

        // Count the number of lines in the file
        int numLines = countLinesInFile(filename);

        // Check if the number of lines meets the conditions
        if (numLines < 3) {
            MsgTree.processFile1(filename);
        } else {
            MsgTree.processFile(filename);
        }
    }

    /**
     * Counts the number of lines in the given file.
     *
     * @param filename The name of the file to count lines.
     * @return The number of lines in the file.
     */
    public static int countLinesInFile(String filename) {
        int count = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            while (reader.readLine() != null) {
                count++;
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return count;
    }
}
