package edu.iastate.cs228.hw4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Represents a binary tree used for decoding messages.
 * 
 * @author vital Nyabashi
 * 4/24/2024
 */
public class MsgTree {
    public char payloadChar;
    public MsgTree left;
    public MsgTree right;

    /**
     * Constructor for internal nodes.
     * 
     * @param left  The left subtree.
     * @param right The right subtree.
     */
    public MsgTree(MsgTree left, MsgTree right) {
        this.left = left;
        this.right = right;
    }

    /**
     * Constructor for leaf nodes.
     * 
     * @param payloadChar The payload character.
     */
    public MsgTree(char payloadChar) {
        this.payloadChar = payloadChar;
        this.left = null;
        this.right = null;
    }

    /**
     * Handles file input, constructs the tree, and decodes the message.
     * 
     * @param filename The name of the file containing the encoding scheme and the message.
     */
    public static void processFile(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String encodingScheme1 = reader.readLine();
            String encodingScheme2 = null;

            if (reader.ready()) {
                encodingScheme2 = reader.readLine();
            }

            String archivedMessage = reader.readLine();

            MsgTree root = buildTree(encodingScheme1, encodingScheme2);

            System.out.println("Character Code");
            System.out.println("-------------------------");
            printCodes(root, "");

            decode(root, archivedMessage);
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }

    /**
     * Handles file input, constructs the tree, and decodes the message.
     * 
     * @param filename The name of the file containing the encoding scheme and the message.
     */
    public static void processFile1(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String encodingScheme1 = reader.readLine();
            String archivedMessage = reader.readLine();

            MsgTree root = buildTree(encodingScheme1, null);

            System.out.println("Character Code");
            System.out.println("-------------------------");
            printCodes(root, "");

            decode(root, archivedMessage);
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }

    /**
     * Constructs the binary tree from the encoding scheme.
     * 
     * @param encodingScheme1 The first line of the encoding scheme.
     * @param encodingScheme2 The second line of the encoding scheme.
     * @return The root of the constructed binary tree.
     */
    private static MsgTree buildTree(String encodingScheme1, String encodingScheme2) {
        String encodingScheme = encodingScheme2 != null ? encodingScheme1 + encodingScheme2 : encodingScheme1;

        Queue<Character> queue = new LinkedList<>();
        for (char ch : encodingScheme.toCharArray()) {
            queue.offer(ch);
        }

        return buildTreeHelper(queue);
    }

    /**
     * Recursive helper method to construct the tree.
     * 
     * @param queue The queue containing characters of the encoding scheme.
     * @return The root of the constructed binary tree.
     */
    private static MsgTree buildTreeHelper(Queue<Character> queue) {
        if (queue.isEmpty())
            return null;

        char currentChar = queue.poll();

        if (currentChar == '^') {
            MsgTree leftSubtree = buildTreeHelper(queue);
            MsgTree rightSubtree = buildTreeHelper(queue);
            return new MsgTree(leftSubtree, rightSubtree);
        } else {
            return new MsgTree(currentChar);
        }
    }

    /**
     * Prints characters and their binary codes.
     * 
     * @param root The root of the binary tree.
     * @param code The code corresponding to the root.
     */
    public static void printCodes(MsgTree root, String code) {
        if (root == null)
            return;

        if (root.left == null && root.right == null) {
            System.out.println(root.payloadChar + " " + code);
        } else {
            printCodes(root.left, code + "0");
            printCodes(root.right, code + "1");
        }
    }

    /**
     * Decodes the message using the constructed binary tree.
     * 
     * @param root The root of the binary tree.
     * @param msg  The encoded message.
     */
    public static void decode(MsgTree root, String msg) {
        if (root == null || msg == null) {
            System.err.println("Error: message or root is null.");
            return;
        }

        StringBuilder decodedMsg = new StringBuilder();
        MsgTree current = root;

        for (char bit : msg.toCharArray()) {
            if (bit == '0') {
                if (current.left != null) {
                    current = current.left;
                }
            } else if (bit == '1') {
                if (current.right != null) {
                    current = current.right;
                }
            } else {
                System.err.println("Error: Invalid bit character in the message.");
                return;
            }

            if (current.left == null && current.right == null) {
                decodedMsg.append(current.payloadChar);
                current = root;
            }
        }

        System.out.println("MESSAGE:");
        System.out.println(decodedMsg.toString());
        printStatistics(msg, decodedMsg.toString());
    }

    /**
     * Calculates and prints message statistics.
     * 
     * @param compressedMsg The compressed message.
     * @param decodedMsg    The decoded message.
     */
    private static void printStatistics(String compressedMsg, String decodedMsg) {
        int originalChars = decodedMsg.length();
        int compressedBits = compressedMsg.length();
        double avgBitsPerChar = (double) compressedBits / originalChars;
        double spaceSavings = (1 - (compressedBits / (originalChars * 16.0))) * 100;

        System.out.println();
        System.out.println("STATISTICS:");
        System.out.println("Avg bits/char: " + avgBitsPerChar);
        System.out.println("Total characters: " + originalChars);
        System.out.println("Space savings: " + spaceSavings + "%");
    }

    /**
     * Counts the number of lines in the given file.
     * 
     * @param filename The name of the file to count lines.
     * @return The number of lines in the file.
     */
    public static int countLinesInFile(String filename) {
        int count = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            while (reader.readLine() != null) {
                count++;
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return count;
    }
}
