package edu.iastate.cs228.hw1;
/**
 * @author Vital Nyabashi
 */

public class Reseller extends TownCell {

	public Reseller(Town p, int r, int c) {
		super(p, r, c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public State who() {
		// TODO Auto-generated method stub
		return State.RESELLER;
	}

	/*
	 * If there are 3 or fewer casual neighbors or 3 or more empty neighbors, change
	 * the state to Empty (E). If none of the above conditions are met, the cell
	 * state remains unchanged.
	 */
	@Override
	public TownCell next(Town tNew) {
		// Get the counts of each type of neighboring cell
		census(nCensus);

		// Now use nCensus to check the conditions
		if (nCensus[CASUAL] <= 3 || nCensus[EMPTY] >= 3) {
			return new Empty(tNew, row, col);
		} else {
			return this; // No change
		}
	}
}