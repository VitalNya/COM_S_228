package edu.iastate.cs228.hw1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * @author Vital Nyabashi
 */

public class ResellerTest {

	@Test
	public void testNext() {
		// Create a sample Town object with a 4x4 grid
		Town t = new Town(4, 4);
		Town tNew = new Town(4, 4);

		// Set the grid configuration
		t.grid[0][0] = new Empty(t, 0, 0);
		t.grid[0][1] = new Reseller(t, 0, 1);
		t.grid[0][2] = new Reseller(t, 0, 2);
		t.grid[0][3] = new Reseller(t, 0, 3);
		t.grid[1][0] = new Reseller(t, 1, 0);
		t.grid[1][1] = new Outage(t, 1, 1);
		t.grid[1][2] = new Casual(t, 1, 2);
		t.grid[1][3] = new Casual(t, 1, 3);
		t.grid[2][0] = new Reseller(t, 2, 0);
		t.grid[2][1] = new Reseller(t, 2, 1);
		t.grid[2][2] = new Streamer(t, 2, 2);
		t.grid[2][3] = new Reseller(t, 2, 3);
		t.grid[3][0] = new Reseller(t, 3, 0);
		t.grid[3][1] = new Reseller(t, 3, 1);
		t.grid[3][2] = new Casual(t, 3, 2);
		t.grid[3][3] = new Reseller(t, 3, 3);
		

		// Call next() method for the Casual cells and update tNew grid
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				if (t.grid[i][j] instanceof Reseller) {
					tNew.grid[i][j] = t.grid[i][j].next(tNew);
				}
			}
		}


//      // Expected grid as a string
		String expectedGrid = "E E E E\n" + "E E E E\n" + "E E E E\n" + "E E E E";

//Convert the Town objects to strings
		String actualGrid = tNew.toString();

//Compare the expected and actual grids
		assertEquals(expectedGrid, actualGrid, "Grids should be the same");

//Print the initial grid
		System.out.println("Initial Grid:");
		System.out.println(t.toString());

//Print the new grid
		System.out.println("New Grid:");
		System.out.println(tNew.toString());
	}

}