package edu.iastate.cs228.hw1;

/**
 * @author Vital Nyabashi
 */

public class Streamer extends TownCell {

	public Streamer(Town p, int r, int c) {
		super(p, r, c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public State who() {
		// TODO Auto-generated method stub
		return State.STREAMER;
	}

	/*
	 * If there is any reseller neighbor, change the state to Outage (O). If there
	 * is any outage neighbor, change the state to Empty (E). If none of the above
	 * conditions are met, the cell state remains unchanged.
	 */
	@Override
	public TownCell next(Town tNew) {
		// TODO Auto-generated method stub

		// Call the census method to update the nCensus array
		census(nCensus); // Use the class name to access the static field

		// Now you can use TownCell.nCensus in your conditions
		if (nCensus[RESELLER] > 0) {
			return new Outage(tNew, row, col);
		} else if (nCensus[OUTAGE] > 0) {
			return new Empty(tNew, row, col);
		}  
		else if (nCensus[EMPTY] + nCensus[OUTAGE] <= 1) {
	        // Rule 6a: Convert to Reseller if conditions are met
	        return new Reseller(tNew, row, col);
	    } else if (nCensus[CASUAL] >= 5) {
	        // Rule 6b: Convert to Streamer if conditions are met
	        return new Streamer(tNew, row, col);
	    } else {
	        // Default: remains an Empty cell
	        return this;
	    }
	}
}
