package edu.iastate.cs228.hw1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// This is a test class for the Empty class
public class EmptyTest {
	
	/*
	 * @author Vital Nyabashi
	 */

	
	// Test method for the who() method of the Empty class
	@Test
	public void testWho() {
		// Create a sample Town object with a 4x4 grid
		Town t = new Town(4, 4);
		Town tNew = new Town(4, 4);

		// Set the grid configuration
		t.grid[0][0] = new Reseller(t, 0, 0);
		t.grid[0][1] = new Empty(t, 0, 1);
		t.grid[0][2] = new Empty(t, 0, 2);
		t.grid[0][3] = new Empty(t, 0, 3);
		t.grid[1][0] = new Empty(t, 1, 0);
		t.grid[1][1] = new Empty(t, 1, 1);
		t.grid[1][2] = new Reseller(t, 1, 2);
		t.grid[1][3] = new Reseller(t, 1, 3);
		t.grid[2][0] = new Empty(t, 2, 0);
		t.grid[2][1] = new Empty(t, 2, 1);
		t.grid[2][2] = new Reseller(t, 2, 2);
		t.grid[2][3] = new Empty(t, 2, 3);
		t.grid[3][0] = new Empty(t, 3, 0);
		t.grid[3][1] = new Empty(t, 3, 1);
		t.grid[3][2] = new Reseller(t, 3, 2);
		t.grid[3][3] = new Empty(t, 3, 3);

		// Call next() method for the Streamer cell at position (2,3) and check the
		// resulting TownCell type
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				if (t.grid[i][j] instanceof Empty) {
					tNew.grid[i][j] = t.grid[i][j].next(tNew);
				}
			}
		}
		
		// Expected grid as a string
		String expectedGrid = "E C C R\n" +
		                      "C C E E\n" +
		                      "C C E R\n" +
		                      "C C E R";

		// Convert the Town objects to strings
		String actualGrid = tNew.toString();

		// Compare the expected and actual grids
		assertEquals(expectedGrid, actualGrid, "Grids should be the same");

		// Print the initial grid
		System.out.println("Initial Grid:");
		System.out.println(t.toString());

		// Print the new grid
		System.out.println("New Grid:");
		System.out.println(tNew.toString());
	}
}
