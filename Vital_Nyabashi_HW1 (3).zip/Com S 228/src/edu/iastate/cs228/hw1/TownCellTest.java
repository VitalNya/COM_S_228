package edu.iastate.cs228.hw1;

/**
 * @author Vital Nyabashi
 */

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class TownCellTest {

    @Test
    void testCensus() {
        // Create a sample Town object with a 4x4 grid
        Town town = new Town(4, 4);

        // Set the grid configuration
        town.grid[0][0] = new Reseller(town, 0, 0);
        town.grid[0][1] = new Casual(town, 0, 1);
        town.grid[0][2] = new Casual(town, 0, 2);
        town.grid[0][3] = new Casual(town, 0, 3);
        town.grid[1][0] = new Casual(town, 1, 0);
        town.grid[1][1] = new Casual(town, 1, 1);
        town.grid[1][2] = new Empty(town, 1, 2);
        town.grid[1][3] = new Casual(town, 1, 3);
        town.grid[2][0] = new Casual(town, 2, 0);
        town.grid[2][1] = new Empty(town, 2, 1);
        town.grid[2][2] = new Casual(town, 2, 2);
        town.grid[2][3] = new Empty(town, 2, 3);
        town.grid[3][0] = new Reseller(town, 3, 0);
        town.grid[3][1] = new Casual(town, 3, 1);
        town.grid[3][2] = new Casual(town, 3, 2);
        town.grid[3][3] = new Casual(town, 3, 3);

        // Call census method for a cell and check the neighbor counts
        town.grid[2][2].census(TownCell.nCensus);

        // Check the neighbor counts
        assertEquals(0, TownCell.nCensus[TownCell.RESELLER], "Reseller count should be 0");
        assertEquals(3, TownCell.nCensus[TownCell.EMPTY], "Empty count should be 3");
        assertEquals(5, TownCell.nCensus[TownCell.CASUAL], "Casual count should be 5");
        assertEquals(0, TownCell.nCensus[TownCell.OUTAGE], "Outage count should be 0");
        assertEquals(0, TownCell.nCensus[TownCell.STREAMER], "Streamer count should be 0");
    }

}
