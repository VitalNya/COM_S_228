package edu.iastate.cs228.hw1;

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Random;

/**
 * @author Vital Nyabashi
 *
 *         The ISPBusiness class performs simulation over a grid plain with
 *         cells occupied by different TownCell types.
 *
 */
public class ISPBusiness {

	private static int profitPerCasualCustomer = 1; // $1 profit per casual customer
	private static int totalCasualCustomers;
	private static int totalProfit; 
	private static int itr = 1;

	/**
	 * Returns a new Town object with updated grid value for next billing cycle.
	 * 
	 * @param tOld: old/current Town object.
	 * @return: New town object.
	 */
	public static Town updatePlain(Town tOld) {
		Town tNew = new Town(tOld.getLength(), tOld.getWidth());
	    for (int i = 0; i < tOld.getLength(); i++) {
	        for (int j = 0; j < tOld.getWidth(); j++) {
	            tNew.grid[i][j] = tOld.grid[i][j].next(tNew);
	        }
	    }
        
	    return tNew;
	}
	
	
	

	/**
	 * Returns the profit for the current state in the town grid.
	 * 
	 * @param town
	 * @return
	 */
	public static int getProfit(Town town) {
		totalCasualCustomers = 0;
		int profit = 0;

		// Iterate through each cell in the town grid
		for (int i = 0; i < town.getLength(); i++) {
			for (int j = 0; j < town.getWidth(); j++) {
				if (town.grid[i][j].who() == State.CASUAL) {
					totalCasualCustomers++;
				}
			}
		}

		 // Calculate total profit based on the number of casual customers
	    profit = totalCasualCustomers * profitPerCasualCustomer;
	    return profit;
	}

	/**
	 * Main method. Interact with the user and ask if user wants to specify elements
	 * of grid via an input file (option: 1) or wants to generate it randomly
	 * (option: 2).
	 * 
	 * Depending on the user choice, create the Town object using respective
	 * constructor and if user choice is to populate it randomly, then populate the
	 * grid here.
	 * 
	 * Finally: For 12 billing cycle calculate the profit and update town object
	 * (for each cycle). Print the final profit in terms of %. You should print the
	 * profit percentage with two digits after the decimal point: Example if profit
	 * is 35.5600004, your output should be:
	 *
	 * 35.56%
	 * 
	 * Note that this method does not throw any exception, so you need to handle all
	 * the exceptions in it.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Random generator = new Random();

		try {
			System.out.println("How to populate grid (type 1 or 2): 1: from a file. 2: randomly with seed");
			int choice = scanner.nextInt();
			Town town;

			if (choice == 1) {
				System.out.println("Please enter file path:");
				String filePath = scanner.next();
				town = new Town(filePath);
			} else if (choice == 2) {
				System.out.println("Provide rows, cols and seed integer separated by spaces:");
				int rows = scanner.nextInt();
				int cols = scanner.nextInt();
				int seed = scanner.nextInt();
				generator = new Random(seed);
				town = new Town(rows, cols);

				// Populate the grid randomly with the given seed
				for (int i = 0; i < rows; i++) {
					for (int j = 0; j < cols; j++) {
						int randomValue = generator.nextInt(5);
						switch (randomValue) {
						case 0:
							town.grid[i][j] = new Reseller(town, i, j);
							break;
						case 1:
							town.grid[i][j] = new Empty(town, i, j);
							break;
						case 2:
							town.grid[i][j] = new Casual(town, i, j);
							break;
						case 3:
							town.grid[i][j] = new Outage(town, i, j);
							break;
						case 4:
							town.grid[i][j] = new Streamer(town, i, j);
							break;
						}
					}

				}
			} else {
				System.out.println("Invalid choice. Exiting...");
				return;
			}

            System.out.println("start:");

			


	        for (int month = 0; month < 11; month++) {
	            String gridState = town.toString();
	            System.out.println(gridState);
	            int profit = getProfit(town); // Calculate profit using the new town
	            town = updatePlain(town); // Update the town and get the new town
	            totalProfit += profit; // Calculate profit using the new town
	            gridState = town.toString();
	            System.out.println("Profit: " + profit);
	            System.out.println("After itr: " + (itr));
	            itr++;
	            System.out.println(gridState);

	        }

			// Calculate profit utilization as a percentage of maximum profit
			int maxProfit = town.getLength() * town.getWidth() * 12;
			double profitUtilization = (double) totalProfit / maxProfit * 100;
			System.out.printf("Profit Utilization: %.2f%%\n", profitUtilization);
			
		} catch (FileNotFoundException e) {
			System.out.println("File not found. Exiting...");
		} finally {
			if (scanner != null) {
				scanner.close();
			}
		}
	}
}