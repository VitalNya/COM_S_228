package edu.iastate.cs228.hw1;


/**
 * @author Vital Nyabashi
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

/**
 * @author Viytal Nyabashi
 *
 */
public class Town {

	private int length;
	private int width; // Row and col (first and second indices)
	public TownCell[][] grid;

	/**
	 * Constructor to be used when user wants to generate grid randomly, with the
	 * given seed. This constructor does not populate each cell of the grid (but
	 * should assign a 2D array to it).
	 * 
	 * @param length
	 * @param width
	 */
	public Town(int length, int width) {
		this.length = length;
		this.width = width;
		grid = new TownCell[length][width];

		// Initialize the grid with Empty cells

		for (int i = 0; i < length; i++) {
			for (int j = 0; j < width; j++) {
				grid[i][j] = new Empty(this, i, j);
			}
		}
	}

	/**
	 * Constructor to be used when user wants to populate grid based on a file.
	 * Please see that it simple throws FileNotFoundException exception instead of
	 * catching it. Ensure that you close any resources (like file or scanner) which
	 * is opened in this function.
	 * 
	 * @param inputFileName
	 * @throws FileNotFoundException
	 */
	public Town(String inputFileName) throws FileNotFoundException {
		File file = new File(inputFileName);
		Scanner scanner = new Scanner(file);
		try {
			length = scanner.nextInt();
			width = scanner.nextInt();
			grid = new TownCell[length][width];
			//scanner.nextLine(); // Move to the next line

			// Populate the grid based on the file contents
			for (int i = 0; i < length; i++) {
				//String line = scanner.nextLine();
				for (int j = 0; j < width; j++) {
					String cellType = scanner.next();
					switch (cellType) {
					case "C":
						grid[i][j] = new Casual(this, i, j);
						break;
					case "S":
						grid[i][j] = new Streamer(this, i, j);
						break;
					case "R":
						grid[i][j] = new Reseller(this, i, j);
						break;
					case "E":
						grid[i][j] = new Empty(this, i, j);
						break;
					case "O":
						grid[i][j] = new Outage(this, i, j);
						break;
					default:
						throw new IllegalArgumentException("Invalid cell type in file: " + cellType);
					}
				}
			}
		} finally {
			if (scanner != null) {
				scanner.close();
			}
		}
	}

	/**
	 * Returns width of the grid.
	 * 
	 * @return
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * Returns length of the grid.
	 * 
	 * @return
	 */
	public int getLength() {
		return length;
	}

	/**
	 * Initialize the grid by randomly assigning cell with one of the following
	 * class object: Casual, Empty, Outage, Reseller OR Streamer
	 */
	public void randomInit(int seed) {
		Random rand = new Random(seed);
		for (int i = 0; i < length; i++) {
			for (int j = 0; j < width; j++) {
				int randomValue = rand.nextInt(5); // Generate random number between 0 and 4
				switch (randomValue) {
				case 0:
					grid[i][j] = new Reseller(this, i, j);
					break;
				case 1:
					grid[i][j] = new Empty(this, i, j);
					break;
				case 2:
					grid[i][j] = new Casual(this, i, j);
					break;
				case 3:
					grid[i][j] = new Outage(this, i, j);
					break;
				case 4:
					grid[i][j] = new Streamer(this, i, j);
					break;
				}
			}
		}
	}
	
	public int[] getNeighborCounts(int row, int col) {
        int[] nCensus = new int[TownCell.NUM_CELL_TYPE];
        TownCell cell = this.grid[row][col];
        cell.census(nCensus);
        return nCensus;
    }

	/**
	 * Output the town grid. For each square, output the first letter of the cell
	 * type. Each letter should be separated either by a single space or a tab. And
	 * each row should be in a new line. There should not be any extra line between
	 * the rows.
	 */
	@Override
	public String toString() {
		String s = "";
		for (int i = 0; i < length; i++) {
			for (int j = 0; j < width; j++) {
				s += grid[i][j].who().toString().charAt(0) + " ";
			}
			// Remove the trailing space and add a newline
			s = s.substring(0, s.length() - 1) + "\n";
		}
		// Remove the trailing newline
		s = s.substring(0, s.length() - 1);
		return s;
	}
}
