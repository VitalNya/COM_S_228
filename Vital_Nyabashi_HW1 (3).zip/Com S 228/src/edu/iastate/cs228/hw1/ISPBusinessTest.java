package edu.iastate.cs228.hw1;

/**
 * @author Vital Nyabashi
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ISPBusinessTest {

    @Test
    public void testUpdatePlainWithEmptyTown() {
        // Create an empty Town object for testing
        Town town = new Town(0, 0);

        // Update the town
        Town updatedTown = ISPBusiness.updatePlain(town);

        // Check that the updated town is not null and is still empty
        assertNotNull(updatedTown);
        assertEquals(0, updatedTown.getLength());
        assertEquals(0, updatedTown.getWidth());
    }

    @Test
    public void testGetProfitWithEmptyTown() {
        // Create an empty Town object for testing
        Town town = new Town(0, 0);

        // Calculate the profit
        int profit = ISPBusiness.getProfit(town);

        // Check that the profit is zero
        assertEquals(0, profit);
    }

    @Test
    public void testUpdatePlainWithNonEmptyTown() {
        // Create a non-empty Town object for testing
        Town town = new Town(4, 4);
        town.randomInit(10);

        // Update the town
        Town updatedTown = ISPBusiness.updatePlain(town);

        // Check that the updated town is not null and has the same dimensions as the original town
        assertNotNull(updatedTown);
        assertEquals(town.getLength(), updatedTown.getLength());
        assertEquals(town.getWidth(), updatedTown.getWidth());
    }

    @Test
    public void testGetProfitWithNonEmptyTown() {
        // Create a non-empty Town object for testing
        Town town = new Town(4, 4);
        town.randomInit(10);

        // Calculate the profit
        int profit = ISPBusiness.getProfit(town);

        // Check that the profit is not negative
        assertTrue(profit >= 0);
    }
}
