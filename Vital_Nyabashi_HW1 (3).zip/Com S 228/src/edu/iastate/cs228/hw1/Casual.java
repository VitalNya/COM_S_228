package edu.iastate.cs228.hw1;

/**
 * @author Vital Nyabashi
 */

public class Casual extends TownCell {

	public Casual(Town p, int r, int c) {
		super(p, r, c);
	}

	@Override
	public State who() {
		return State.CASUAL;
	}

	@Override
	public TownCell next(Town tNew) {
		// Rule 6a: Convert to Reseller if conditions are met
		census(nCensus);

		
		if (nCensus[EMPTY] + nCensus[OUTAGE] <= 1) {
			return new Reseller(tNew, row, col);
		} 
		// Rule 6b: If none of the above rules apply, any cell with 5 or more casual
		// neighbors becomes a Streamer.
		else if (nCensus[CASUAL] >= 5) {
			return new Streamer(tNew, row, col);
		}
		// Rule 1a: If there is any reseller in its neighborhood, then the reseller
		// causes outage in the casual user cell.
		else if (nCensus[RESELLER] > 0) {
			return new Outage(tNew, row, col);
		}
		// Rule 1b: Otherwise, if there is any neighbor who is a streamer, then the
		// casual user also becomes a streamer.
		else if (nCensus[STREAMER] > 0) {
			return new Streamer(tNew, row, col);
		}
		// If none of the rules apply, the cell state remains unchanged.
		else {
			return this; // No change
		}
	}
}

