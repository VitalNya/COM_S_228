package edu.iastate.cs228.hw1;

/**
 * @author Vital Nyabashi
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TownTest {

	@Test
	public void testGetWidthAndLength() {
		// Test with a variety of town sizes
		for (int size = 0; size <= 10; size++) {
			Town town = new Town(size, size);
			assertEquals(size, town.getWidth(), "Width of the town should be " + size);
			assertEquals(size, town.getLength(), "Length of the town should be " + size);
		}
	}

	@Test
	void testGetNeighborCounts() {
		// Create a sample Town object with a 4x4 grid
		Town town = new Town(4, 4);
		// Populate the grid with the desired configuration
		town.grid[0][0] = new Reseller(town, 0, 0);
		town.grid[0][1] = new Casual(town, 0, 1);
		town.grid[0][2] = new Casual(town, 0, 2);
		town.grid[0][3] = new Casual(town, 0, 3);
		town.grid[1][0] = new Casual(town, 1, 0);
		town.grid[1][1] = new Casual(town, 1, 1);
		town.grid[1][2] = new Empty(town, 1, 2);
		town.grid[1][3] = new Casual(town, 1, 3);
		town.grid[2][0] = new Casual(town, 2, 0);
		town.grid[2][1] = new Empty(town, 2, 1);
		town.grid[2][2] = new Casual(town, 2, 2);
		town.grid[2][3] = new Empty(town, 2, 3);
		town.grid[3][0] = new Reseller(town, 3, 0);
		town.grid[3][1] = new Casual(town, 3, 1);
		town.grid[3][2] = new Casual(town, 3, 2);
		town.grid[3][3] = new Casual(town, 3, 3);

		// Get the neighbor counts for a specific cell
		int[] neighborCounts = town.getNeighborCounts(1, 1);

		// Verify the counts
		assertEquals(5, neighborCounts[TownCell.CASUAL], "correct count for Casual neighbors");
		assertEquals(2, neighborCounts[TownCell.EMPTY], "correct count for Empty neighbors");
		assertEquals(0, neighborCounts[TownCell.OUTAGE], "correct count for Outage neighbors");
		assertEquals(1, neighborCounts[TownCell.RESELLER], "correct count for Reseller neighbors");
		assertEquals(0, neighborCounts[TownCell.STREAMER], "correct count for Streamer neighbors");
	}

	@Test
	public void testRandomInit() {
		// Test with a variety of town sizes and seeds
		for (int size = 0; size <= 10; size++) {
			for (int seed = 0; seed <= 10; seed++) {
				Town town = new Town(size, size);
				town.randomInit(seed);

				// Add assertions to check the state of the town after random initialization
				for (int i = 0; i < size; i++) {
					for (int j = 0; j < size; j++) {
						TownCell cell = town.grid[i][j];
						State cellState = cell.who();

						// Check that the cell state is one of the possible states
						assertTrue(
								cellState == State.RESELLER || cellState == State.EMPTY || cellState == State.CASUAL
										|| cellState == State.OUTAGE || cellState == State.STREAMER,
								"Cell state should be one of the possible states");

					}
				}
			}
		}
	}

	@Test
	public void testToString() {
		// Create a sample Town object with a 4x4 grid
		Town town = new Town(4, 4);
		town.grid[0][0] = new Outage(town, 0, 0);
		town.grid[0][1] = new Reseller(town, 0, 1);
		town.grid[0][2] = new Outage(town, 0, 2);
		town.grid[0][3] = new Reseller(town, 0, 3);
		town.grid[1][0] = new Empty(town, 1, 0);
		town.grid[1][1] = new Empty(town, 1, 1);
		town.grid[1][2] = new Casual(town, 1, 2);
		town.grid[1][3] = new Outage(town, 1, 3);
		town.grid[2][0] = new Empty(town, 2, 0);
		town.grid[2][1] = new Streamer(town, 2, 1);
		town.grid[2][2] = new Outage(town, 2, 2);
		town.grid[2][3] = new Streamer(town, 2, 3);
		town.grid[3][0] = new Empty(town, 3, 0);
		town.grid[3][1] = new Outage(town, 3, 1);
		town.grid[3][2] = new Reseller(town, 3, 2);
		town.grid[3][3] = new Reseller(town, 3, 3);

		// Expected string representation of the town
		String expectedString = "O R O R\n" + "E E C O\n" + "E S O S\n" + "E O R R";

		// Get the actual string representation of the town
		String actualString = town.toString();

		// Check if the actual string matches the expected string
		assertEquals(expectedString, actualString, "String representation of the town should match the expected value");
	}

}
