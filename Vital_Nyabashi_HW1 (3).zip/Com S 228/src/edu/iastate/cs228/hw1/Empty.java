package edu.iastate.cs228.hw1;

/**
 * @author Vital Nyabashi
 */

public class Empty extends TownCell {

	public Empty(Town p, int r, int c) {
		super(p, r, c);
	}

	@Override
	public State who() {
		return State.EMPTY;
	}

	/*
	 * If there are 1 or fewer empty neighbors and 1 or fewer outage neighbors,
	 * change the state to Reseller (R). If none of the above conditions are met,
	 * the cell state remains unchanged.
	 */
	@Override
	public TownCell next(Town tNew) {
		census(nCensus);
        
		// Rule 6a: Convert to Reseller if conditions are met
		if (nCensus[EMPTY] + nCensus[OUTAGE] <= 1) {
			return new Reseller(tNew, row, col);
		} else {
			return new Casual(tNew, row, col);
		}
	}
}